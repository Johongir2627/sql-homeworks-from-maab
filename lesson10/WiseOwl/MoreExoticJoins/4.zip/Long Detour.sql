use Music_01

select
	al.Title
	,al.Release_date
	,ar.Artist
	,t.Tour_name
from
	dbo.Album as al
	inner join dbo.Artist as ar on ar.Artist_ID = al.Artist_ID
	inner join dbo.Tour as t on al.Album_ID = t.Album_ID


select
	al.Title
	,al.Release_date
	,ar.Artist
	,isnull(t.Tour_name, concat('No associated tour for ', al.Title)) as Tour_name
from
	dbo.Album as al
	inner join dbo.Artist as ar on ar.Artist_ID = al.Artist_ID
	left join dbo.Tour as t on al.Album_ID = t.Album_ID
where
	t.Tour_ID is null


select
	al.Title
	,al.Release_date
	,concat(al.Album_mins, 'm ', al.Album_secs, 's') as Album_length
	,ar.Artist
	,isnull(t.Tour_name, concat('No associated tour for ', al.Title)) as Tour_name
from
	dbo.Album as al
	inner join dbo.Artist as ar on ar.Artist_ID = al.Artist_ID
	left join dbo.Tour as t on al.Album_ID = t.Album_ID
where
	t.Tour_ID is null
	and al.Title like '%road%'
	and al.Title not like '%broad%'
order by
	al.Album_mins desc
	,al.Album_secs desc
