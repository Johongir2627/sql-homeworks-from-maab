use Music_01

select
	a.Artist
	,t.Tour_name
	,s.Show_date
	,v.Venue
	,s.Leg
	,s.Tickets_sold
from
	dbo.Show as s
	inner join dbo.Venue as v on v.Venue_ID = s.Venue_ID
	inner join dbo.City as c on c.City_ID = v.City_ID
	inner join dbo.Tour as t on t.Tour_ID = s.Tour_ID
	inner join dbo.Artist as a on a.Artist_ID = t.Artist_ID
where
	c.City = 'Manchester'
order by
	Show_date asc