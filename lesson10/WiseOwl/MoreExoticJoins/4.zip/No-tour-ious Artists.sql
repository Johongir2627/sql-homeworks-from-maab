use Music_01

select
	a.Artist
	,isnull(t.Tour_name, concat('No tours found for ', a.Artist)) as Tour_name
from
	dbo.Artist as a
	left join dbo.Tour as t on a.Artist_ID = t.Artist_ID
where
	t.Tour_ID is null
order by
	a.Artist asc
	,t.Tour_name asc