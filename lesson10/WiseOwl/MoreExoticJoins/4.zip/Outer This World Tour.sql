use Music_01

select
	t.Tour_name
	,t.Start_date
	,isnull(a.Title, 'No associated album') as Album_title
from
	dbo.Tour as t
	left outer join dbo.Album as a
		on a.Album_ID = t.Album_ID
order by
	t.Tour_name