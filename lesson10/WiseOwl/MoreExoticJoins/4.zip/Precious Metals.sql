use Music_01

select
	a.Title
	,a.[US_sales_(m)]
	,s.Subgenre
from
	dbo.Album as a
	inner join dbo.Subgenre as s on a.Subgenre_ID = s.Subgenre_ID
	inner join dbo.Genre as g on s.Genre_ID = g.Genre_ID
where
	a.[US_sales_(m)] >= 0.5
	and a.[US_sales_(m)] < 10
	and g.Genre = 'metal'
order by
	a.Title asc
