use Music_01

select
	r.Record_label
	,count(*) as Count_of_albums
	,cast(avg(a.[US_sales_(m)]) as decimal(18, 2)) as [Avg_sales_(m)]
from
	dbo.Record_Label as r
	inner join dbo.Album as a on r.Record_label_ID = a.Record_label_ID
group by
	r.Record_label




select
	r.Record_label
	,count(*) as Count_of_albums
	,cast(avg(a.[US_sales_(m)]) as decimal(18, 2)) as [Avg_sales_(m)]
from
	dbo.Record_Label as r
	inner join dbo.Album as a on r.Record_label_ID = a.Record_label_ID
group by
	r.Record_label with rollup




select
	isnull(p.Parent_company, 'GRAND') as [Parent_company]
	,isnull(r.Record_label, 'TOTAL') as [Record_label]
	,count(*) as Count_of_albums
	,cast(avg(a.[US_sales_(m)]) as decimal(18, 2)) as [Avg_sales_(m)]
from
	dbo.Parent_Company as p
	inner join dbo.Record_Label as r on p.Parent_company_ID = r.Parent_company_ID
	inner join dbo.Album as a on r.Record_label_ID = a.Record_label_ID
group by
	p.Parent_company
	,r.Record_label with rollup
