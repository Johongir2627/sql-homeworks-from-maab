use Music_01

select
	a.Artist_type
	,count(*) as Number_of_artists
from
	dbo.Artist as a
group by
	a.Artist_type
