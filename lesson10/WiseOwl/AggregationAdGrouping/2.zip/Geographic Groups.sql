use Music_01

select
	v.Venue
	,count(*) as Count_of_shows
	,sum(s.Tickets_sold) as Sum_tickets_sold
	,cast(avg(cast(s.Revenue_$ as decimal)) as decimal(18, 2)) as Avg_revenue_$
from
	dbo.Show as s
	inner join dbo.Venue as v on v.Venue_ID = s.Venue_ID
group by
	v.Venue
order by
	Count_of_shows desc



select
	ci.City
	,count(*) as Count_of_shows
	,sum(s.Tickets_sold) as Sum_tickets_sold
	,cast(avg(cast(s.Revenue_$ as decimal)) as decimal(18, 2)) as Avg_revenue_$
from
	dbo.Show as s
	inner join dbo.Venue as v on v.Venue_ID = s.Venue_ID
	inner join dbo.City as ci on ci.City_ID = v.City_ID
group by
	ci.City
order by
	Count_of_shows desc


select
	co.Country
	,count(*) as Count_of_shows
	,sum(s.Tickets_sold) as Sum_tickets_sold
	,cast(avg(cast(s.Revenue_$ as decimal)) as decimal(18, 2)) as Avg_revenue_$
from
	dbo.Show as s
	inner join dbo.Venue as v on v.Venue_ID = s.Venue_ID
	inner join dbo.City as ci on ci.City_ID = v.City_ID
	inner join dbo.Country as co on co.Country_ID = ci.Country_ID
group by
	co.Country
order by
	Count_of_shows desc


select
	cn.Continent
	,count(*) as Count_of_shows
	,sum(s.Tickets_sold) as Sum_tickets_sold
	,cast(avg(cast(s.Revenue_$ as decimal)) as decimal(18, 2)) as Avg_revenue_$
from
	dbo.Show as s
	inner join dbo.Venue as v on v.Venue_ID = s.Venue_ID
	inner join dbo.City as ci on ci.City_ID = v.City_ID
	inner join dbo.Country as co on co.Country_ID = ci.Country_ID
	inner join dbo.Continent as cn on cn.Continent_ID = co.Continent_ID
group by
	cn.Continent
order by
	Count_of_shows desc


select
	cn.Continent
	,co.Country
	,ci.City
	,v.Venue
	,count(*) as Count_of_shows
	,sum(s.Tickets_sold) as Sum_tickets_sold
	,cast(avg(cast(s.Revenue_$ as decimal)) as decimal(18, 2)) as Avg_revenue_$
from
	dbo.Show as s
	inner join dbo.Venue as v on v.Venue_ID = s.Venue_ID
	inner join dbo.City as ci on ci.City_ID = v.City_ID
	inner join dbo.Country as co on co.Country_ID = ci.Country_ID
	inner join dbo.Continent as cn on cn.Continent_ID = co.Continent_ID
group by
	cn.Continent
	,co.Country
	,ci.City
	,v.Venue
order by
	Count_of_shows desc
