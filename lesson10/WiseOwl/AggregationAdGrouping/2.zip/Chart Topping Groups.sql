use Music_01

select
	ar.Artist
	,count(*) as Count_of_albums
	,cast(sum(al.[US_sales_(m)]) as decimal(18, 2)) as [Sum_of_sales_(m)]
	,cast(avg(al.[US_sales_(m)]) as decimal(18, 2)) as [Avg_of_sales_(m)]
from
	dbo.Artist as ar
	inner join dbo.Album as al on ar.Artist_ID = al.Artist_ID
where
	al.US_Billboard_200_peak = 1
group by
	ar.Artist
having
	avg(al.[US_sales_(m)]) >= 10
order by
	Count_of_albums desc
